---
title: "FDA clears a new at-home HPV self-collection test"
date: 2026-07-08T09:00:00.000Z
summary: "Patients can now collect their own sample for cervical cancer screening at home and mail it in, instead of requiring an in-clinic pelvic exam for the initial test."
sourceName: "FDA"
sourceUrl: ""
---
